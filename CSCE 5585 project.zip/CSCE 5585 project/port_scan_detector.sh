#!/bin/bash
# Port Scan Detection for Ransomware Monitoring
# CSCE 5585 Project - Complacence

TARGET_HOST=${1:-localhost}
OUTPUT_FILE="port_scan_results_$(date +%Y%m%d_%H%M%S).txt"

echo "[+] Starting Port Scan Detection on $TARGET_HOST"
echo "[+] Scan initiated at: $(date)" | tee -a $OUTPUT_FILE

# this will perform a comprehensive port scan to detect open services
nmap -p- -sT -sV --reason $TARGET_HOST -oN $OUTPUT_FILE

# this will extract interesting ports
echo "[+] Open Ports Summary:" | tee -a $OUTPUT_FILE
grep "open" $OUTPUT_FILE | grep -v "#" | tee -a $OUTPUT_FILE

echo "[+] Port scan detection complete. Results saved to $OUTPUT_FILE"