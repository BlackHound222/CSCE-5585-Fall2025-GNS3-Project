#!/bin/bash
# Stealth Network Monitoring for Ransomware Detection
# CSCE 5585 Project - Complacence

TARGET=${1:-localhost}
OUTPUT="stealth_scan_$(date +%Y%m%d_%H%M%S).xml"

echo "[+] Starting Stealth SYN Scan for Ransomware Detection"
echo "[+] Target: $TARGET"

# this will perform a stealth SYN scan to avoid detection
nmap -sS -Pn -A -O --host-timeout 5m $TARGET -oX $OUTPUT

# this will extract OS detection information
echo "[+] Operating System Detection:"
grep "osmatch" $OUTPUT | sed 's/.*name="\([^"]*\)".*/\1/' | sort -u

# this will extract service information
echo "[+] Services Detected:"
grep "service name" $OUTPUT | sed 's/.*name="\([^"]*\)".*/\1/' | sort -u

echo "[+] Stealth scan complete. Results saved to $OUTPUT"