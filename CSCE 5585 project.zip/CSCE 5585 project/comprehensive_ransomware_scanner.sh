#!/bin/bash
# Bwalya Maele
# Comprehensive Ransomware Network Scanner
# CSCE 5585 Project - Complacence

print_banner() {
    echo "==============================================="
    echo "  Ransomware Network Scanner - Complacence"
    echo "  CSCE 5585 Project"
    echo "==============================================="
    echo
}

show_help() {
    echo "Usage: $0 [OPTIONS] TARGET"
    echo "Options:"
    echo "  -h, --help     Show this help message"
    echo "  -v, --verbose  Enable verbose output"
    echo "  -o, --output   Specify output directory"
    echo
    echo "Examples:"
    echo "  $0 192.168.1.0/24"
    echo "  $0 -v localhost"
    echo "  $0 -o /home/kali/scans 10.0.0.0/16"
}

# Default values
VERBOSE=false
OUTPUT_DIR="./scan_results"
TARGET=""

# this will parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            show_help
            exit 0
            ;;
        -v|--verbose)
            VERBOSE=true
            shift
            ;;
        -o|--output)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        -*)
            echo "Unknown option $1"
            show_help
            exit 1
            ;;
        *)
            TARGET="$1"
            shift
            ;;
    esac
done

# this will validate target
if [[ -z "$TARGET" ]]; then
    echo "Error: No target specified"
    show_help
    exit 1
fi

# Create output directory
mkdir -p "$OUTPUT_DIR"

# this will set scan identifiers
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BASE_NAME="ransomware_scan_${TIMESTAMP}"
FULL_PATH="${OUTPUT_DIR}/${BASE_NAME}"

print_banner

echo "[+] Starting Comprehensive Ransomware Network Scan"
echo "[+] Target: $TARGET"
echo "[+] Output Directory: $OUTPUT_DIR"
echo "[+] Scan Started: $(date)"
echo

# Phase 1: Host Discovery
echo "[+] Phase 1: Host Discovery"
if $VERBOSE; then
    nmap -sn $TARGET -oA "${FULL_PATH}_hosts" --reason
else
    nmap -sn $TARGET -oA "${FULL_PATH}_hosts" > /dev/null 2>&1
fi

HOST_COUNT=$(grep "Nmap scan report" "${FULL_PATH}_hosts.nmap" | wc -l)
echo "[+] Discovered $HOST_COUNT live hosts"
echo

# Phase 2: Port Scanning
echo "[+] Phase 2: Port Scanning"
echo "[+] Scanning for ransomware-related ports..."

# this will scan common ransomware communication ports
RANSOMWARE_PORTS="21,22,23,25,53,80,110,139,143,443,445,993,995,1433,3306,3389,5432,5900,8080,8443"

if $VERBOSE; then
    nmap -p $RANSOMWARE_PORTS -sS -Pn -sV --version-intensity 3 $TARGET -oA "${FULL_PATH}_ports" --reason
else
    nmap -p $RANSOMWARE_PORTS -sS -Pn -sV --version-intensity 3 $TARGET -oA "${FULL_PATH}_ports" > /dev/null 2>&1
fi

# this will extract open ports
echo "[+] Open ports detected:"
grep "open" "${FULL_PATH}_ports.nmap" | grep -v "#" | cut -d'/' -f1,3,5 | column -t

# Phase 3: Service Detection
echo
echo "[+] Phase 3: Service Detection"

if $VERBOSE; then
    nmap -sV --version-intensity 5 $TARGET -oA "${FULL_PATH}_services" --reason
else
    nmap -sV --version-intensity 5 $TARGET -oA "${FULL_PATH}_services" > /dev/null 2>&1
fi

# this will check for vulnerable services
echo "[+] Checking for potentially vulnerable services:"
VULNERABLE_SERVICES=("smb" "microsoft-ds" "mssql" "mysql" "postgresql" "vnc" "telnet" "ftp")

for service in "${VULNERABLE_SERVICES[@]}"; do
    grep -i "$service" "${FULL_PATH}_services.nmap" > /dev/null
    if [[ $? -eq 0 ]]; then
        echo "[WARNING] Potentially vulnerable service detected: $service"
        grep -i "$service" "${FULL_PATH}_services.nmap"
    fi
done

# Phase 4: OS Detection
echo
echo "[+] Phase 4: Operating System Detection"

if $VERBOSE; then
    nmap -O $TARGET -oA "${FULL_PATH}_os" --reason
else
    nmap -O $TARGET -oA "${FULL_PATH}_os" > /dev/null 2>&1
fi

# this will extract OS information
echo "[+] Operating Systems Detected:"
grep "OS details" "${FULL_PATH}_os.nmap" | cut -d':' -f2 || echo "No OS information available"

# this will generate Summary Report
echo
echo "[+] Generating Summary Report"

cat > "${FULL_PATH}_summary.txt" << EOF
Ransomware Network Scan Summary
================================

Scan Information:
- Target: $TARGET
- Start Time: $(date)
- Nmap Version: $(nmap --version | head -1)

Host Discovery:
- Live Hosts Found: $HOST_COUNT

Critical Findings:
EOF

# this will add warnings for suspicious ports/services
grep "open" "${FULL_PATH}_ports.nmap" | grep -E "(139|445|3389)" >> "${FULL_PATH}_summary.txt" 2>/dev/null || echo "No critical ports detected" >> "${FULL_PATH}_summary.txt"

cat >> "${FULL_PATH}_summary.txt" << EOF

Scan Files Generated:
- Host Discovery: ${BASE_NAME}_hosts.nmap
- Port Scanning: ${BASE_NAME}_ports.nmap
- Service Detection: ${BASE_NAME}_services.nmap
- OS Detection: ${BASE_NAME}_os.nmap
- Summary Report: ${BASE_NAME}_summary.txt

Scan Completed: $(date)
EOF

echo "[+] Scan completed successfully!"
echo "[+] Results saved to: $OUTPUT_DIR"
echo "[+] Summary report: ${FULL_PATH}_summary.txt"