#!/bin/bash
# Network Discovery Script for Ransomware Monitoring
# CSCE 5585 Project - Complacence

echo "[+] Starting Network Discovery Scan"
echo "[+] Scan Time: $(date)"

# this will discover live hosts on local network
nmap -sn 192.168.1.0/24 -oN network_hosts.txt

# This will parse results
echo "[+] Live Hosts Detected:"
grep report network_hosts.txt | awk '{print $NF}'

echo "[+] Network discovery complete. Results saved to network_hosts.txt"