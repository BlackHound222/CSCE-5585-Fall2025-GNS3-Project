#!/bin/bash
# Ransomware Network Behavior Detection
# CSCE 5585 Project - Complacence

TARGET_NETWORK=${1:-192.168.1.0/24}
SCAN_NAME="ransomware_scan_$(date +%Y%m%d_%H%M%S)"

echo "[+] Initiating Ransomware Behavior Network Scan"
echo "[+] Target Network: $TARGET_NETWORK"
echo "[+] Scan Name: $SCAN_NAME"

# Scan for common ransomware communication ports
# Ports: 443 (HTTPS), 80 (HTTP), 21 (FTP), 22 (SSH), 139/445 (SMB)
nmap -p 21,22,80,139,443,445,3389,8080,8443 -sS -Pn -v $TARGET_NETWORK -oA $SCAN_NAME

# this will check for services commonly used by ransomware
echo "[+] Checking for potentially vulnerable services..."

# this will parse results for suspicious open ports
echo "[+] Suspicious Open Ports Detected:"
grep "open" ${SCAN_NAME}.nmap | grep -E "(139|445|3389|8080|8443)" | tee -a ${SCAN_NAME}_suspicious.txt

# this will generate summary report
echo "[+] Scan Summary Report:" > ${SCAN_NAME}_summary.txt
echo "Scan Date: $(date)" >> ${SCAN_NAME}_summary.txt
echo "Target Network: $TARGET_NETWORK" >> ${SCAN_NAME}_summary.txt
echo "Suspicious Hosts:" >> ${SCAN_NAME}_summary.txt
grep "Nmap scan report" ${SCAN_NAME}.nmap >> ${SCAN_NAME}_summary.txt

echo "[+] Ransomware behavior scan complete."
echo "[+] Detailed results: ${SCAN_NAME}.nmap"
echo "[+] Summary report: ${SCAN_NAME}_summary.txt"